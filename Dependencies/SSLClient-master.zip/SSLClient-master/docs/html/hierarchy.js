var hierarchy =
[
    [ "br_ssl_session_parameters", null, [
      [ "SSLSession", "class_s_s_l_session.html", null ]
    ] ],
    [ "Client", null, [
      [ "SSLClientImpl", "class_s_s_l_client_impl.html", [
        [ "SSLClient< C, SessionCache >", "class_s_s_l_client.html", null ]
      ] ]
    ] ]
];