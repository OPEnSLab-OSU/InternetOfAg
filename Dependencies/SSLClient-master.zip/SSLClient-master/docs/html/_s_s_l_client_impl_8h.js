var _s_s_l_client_impl_8h =
[
    [ "SSLClientImpl", "class_s_s_l_client_impl.html", "class_s_s_l_client_impl" ],
    [ "DebugLevel", "_s_s_l_client_impl_8h.html#ab658e6d84759440dbf3c890446075395", [
      [ "SSL_NONE", "_s_s_l_client_impl_8h.html#ab658e6d84759440dbf3c890446075395af16e73d8cce9a2c987bde5afe5524d7f", null ],
      [ "SSL_ERROR", "_s_s_l_client_impl_8h.html#ab658e6d84759440dbf3c890446075395ad3f9f0591dcabc4fac1222c462bf17ec", null ],
      [ "SSL_WARN", "_s_s_l_client_impl_8h.html#ab658e6d84759440dbf3c890446075395a86c8fdfc38831619d5ed73dff5b0911d", null ],
      [ "SSL_INFO", "_s_s_l_client_impl_8h.html#ab658e6d84759440dbf3c890446075395a8c0bb62be3d0e6bfe5ed2f7ebbed3d91", null ]
    ] ],
    [ "Error", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5", [
      [ "SSL_OK", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5a1218c16a5bf50589e0c498983851612c", null ],
      [ "SSL_CLIENT_CONNECT_FAIL", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5aaa79045423a355885738cd239dff6c2b", null ],
      [ "SSL_BR_CONNECT_FAIL", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5afb90a695332a7c96044dc97c577ee3c3", null ],
      [ "SSL_CLIENT_WRTIE_ERROR", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5a1d5f8248fac85f56b05d49c7cb53494b", null ],
      [ "SSL_BR_WRITE_ERROR", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5a1d9afd51e0012e791f099657797c9aa9", null ],
      [ "SSL_INTERNAL_ERROR", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5afd588a56dcccf4f6943defa7ab699afc", null ],
      [ "SSL_OUT_OF_MEMORY", "_s_s_l_client_impl_8h.html#a2c3e4bb40f36b262a5214e2da2bca9c5adec799caf92b4fe2b6d2b362136f6ef6", null ]
    ] ]
];