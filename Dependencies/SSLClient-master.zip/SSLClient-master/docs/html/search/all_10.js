var searchData=
[
  ['unix_5ftimestamp',['UNIX_TIMESTAMP',['../time__macros_8h.html#a04e76e262f0920441e5f0c5552e83487',1,'time_macros.h']]],
  ['unix_5ftimestamp_5futc',['UNIX_TIMESTAMP_UTC',['../time__macros_8h.html#a2af3d1d741ae2b49627adf56bbc95dc3',1,'time_macros.h']]]
];
